package com.app.tictactoe;
import java.util.Random;

public class TicTacToeGame {
    public static final int GRID_SIZE = 3;

    // Creates an array of potential integer values
    private Integer[][] mTicTacToeGrid;

    //Creates the array using the GRID_SIZE
    public TicTacToeGame() {
        mTicTacToeGrid = new Integer[GRID_SIZE][GRID_SIZE];
    }

    //Initializes the values in the grid to 0.
    public void newGame() {
        Random randomNumGenerator = new Random();
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                mTicTacToeGrid[row][col] = 0;
            }
        }
    }

    //Returns a boolean value depending on if a player has already selected the button
    public Boolean isSelected(int row, int col) {
        if (mTicTacToeGrid[row][col] == 0){
            return false;
        }
        return true;
    }


    //We can use this function call to do select depending on the active player.
    // Make active player a global variable
    public void selectGridSpace(int row, int col) {

    }

    public boolean isGameOver() {

        //Checking each row
        for (int row = 0; row < GRID_SIZE; row++) {
            Integer line_total = 0;
            for (int col = 0; col < GRID_SIZE; col++) {
                line_total = line_total +  mTicTacToeGrid[row][col];
                if (line_total == 3 || line_total == -3) {

                    //we can add logic here to return the winners name
                    //but it may be a better idea to use this function
                    //in a if statement then if use the current_player
                    //variable to declare winner and show winner's popup

                    return true;
                }
            }
        }

        //Checking each column
        for (int col = 0; col < GRID_SIZE; col++) {
            Integer line_total = 0;
            for (int row = 0; row < GRID_SIZE; row++) {
                line_total = line_total +  mTicTacToeGrid[row][col];
                if (line_total == 3 || line_total == -3) {

                    //we can add logic here to return the winners name
                    //but it may be a better idea to use this function
                    //in a if statement then if use the current_player
                    //variable to declare winner and show winner's popup

                    return true;
                }
            }
        }

        //Add in the code for the diagonals. It should already be implemented in the fxml version

        return false;
    }


}






/*
    public String getState() {
        StringBuilder boardString = new StringBuilder();
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                char value = mLightsGrid[row][col] ? 'T' : 'F';
                boardString.append(value);
            }
        }

        return boardString.toString();
    }

    public void setState(String gameState) {
        int index = 0;
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                mLightsGrid[row][col] = gameState.charAt(index) == 'T';
                index++;
            }
        }
    }
*/